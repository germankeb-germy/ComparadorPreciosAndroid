package com.example.comparador

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

data class Product(
    val id: String,
    val code: String,
    val name: String,
    val san: String,
    val zorro: String
)

enum class PriceTarget(val label: String) {
    SAN_ANTONIO("San Antonio"),
    EL_ZORRO("El Zorro")
}

data class ReceiptItem(
    val rawLine: String,
    val description: String,
    val price: String,
    val productId: String? = null,
    val productName: String? = null,
    val score: Double = 0.0
)

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("comparador_local", Context.MODE_PRIVATE)

    fun productIdForCode(code: String): String? = prefs.getString("code_$code", null)

    fun assignCode(code: String, productId: String) {
        prefs.edit().putString("code_$code", productId).apply()
    }

    fun sanPrice(product: Product): String =
        prefs.getString("san_${product.id}", null) ?: product.san

    fun zorroPrice(product: Product): String =
        prefs.getString("zorro_${product.id}", null) ?: product.zorro

    fun savePrices(productId: String, san: String, zorro: String) {
        prefs.edit()
            .putString("san_$productId", san.trim())
            .putString("zorro_$productId", zorro.trim())
            .apply()
    }

    fun saveTicketPrice(product: Product, target: PriceTarget, price: String) {
        when (target) {
            PriceTarget.SAN_ANTONIO -> savePrices(product.id, price, zorroPrice(product))
            PriceTarget.EL_ZORRO -> savePrices(product.id, sanPrice(product), price)
        }
    }

    fun receiptAlias(description: String): String? =
        prefs.getString("ticket_alias_${receiptAliasKey(description)}", null)

    fun saveReceiptAlias(description: String, productId: String) {
        prefs.edit()
            .putString("ticket_alias_${receiptAliasKey(description)}", productId)
            .apply()
    }

    fun localProducts(): List<Product> {
        val raw = prefs.getString("local_products", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        Product(
                            id = o.optString("id"),
                            code = o.optString("code"),
                            name = o.optString("name"),
                            san = o.optString("san"),
                            zorro = o.optString("zorro")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun createProduct(code: String, name: String, san: String, zorro: String): Product {
        val product = Product(
            id = "local_${System.currentTimeMillis()}",
            code = code.trim(),
            name = name.trim(),
            san = san.trim(),
            zorro = zorro.trim()
        )
        val current = localProducts().toMutableList()
        current += product

        val array = JSONArray()
        current.forEach { p ->
            array.put(
                JSONObject()
                    .put("id", p.id)
                    .put("code", p.code)
                    .put("name", p.name)
                    .put("san", p.san)
                    .put("zorro", p.zorro)
            )
        }
        prefs.edit().putString("local_products", array.toString()).apply()
        assignCode(product.code, product.id)
        return product
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val products = loadProducts()
        setContent {
            App(products)
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    result += current.toString().trim()
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result += current.toString().trim()
        return result
    }

    private fun loadProducts(): List<Product> {
        val out = mutableListOf<Product>()
        assets.open("productos.csv").use { input ->
            BufferedReader(InputStreamReader(input)).useLines { lines ->
                lines.drop(1).forEachIndexed { index, line ->
                    if (line.isBlank()) return@forEachIndexed
                    val p = parseCsvLine(line)
                    if (p.size >= 4 && p[0].isNotBlank()) {
                        out += Product(
                            id = index.toString(),
                            code = p[1].trim(),
                            name = p[0].trim(),
                            san = p[2].trim(),
                            zorro = p[3].trim()
                        )
                    }
                }
            }
        }
        return out
    }
}

@Composable
fun App(products: List<Product>) {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var code by remember { mutableStateOf("") }
    var ignoredCode by remember { mutableStateOf<String?>(null) }
    var dataVersion by remember { mutableStateOf(0) }
    var showAssign by remember { mutableStateOf(false) }
    var showNewProduct by remember { mutableStateOf(false) }
    var showEditPrices by remember { mutableStateOf<Product?>(null) }
    var showTicketStore by remember { mutableStateOf(false) }
    var ticketTarget by remember { mutableStateOf<PriceTarget?>(null) }
    var ticketUri by remember { mutableStateOf<Uri?>(null) }
    var receiptItems by remember { mutableStateOf<List<ReceiptItem>>(emptyList()) }
    var assigningReceiptIndex by remember { mutableStateOf<Int?>(null) }
    var showReceiptReview by remember { mutableStateOf(false) }
    var receiptMessage by remember { mutableStateOf<String?>(null) }
    var processingReceipt by remember { mutableStateOf(false) }

    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> cameraGranted = granted }

    LaunchedEffect(Unit) {
        if (!cameraGranted) cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    val allProducts = remember(dataVersion, products) {
        products + store.localProducts()
    }

    val result = remember(code, dataVersion, allProducts) {
        if (code.isBlank()) null
        else {
            val mappedId = store.productIdForCode(code)
            val base = if (mappedId != null) {
                allProducts.firstOrNull { it.id == mappedId }
            } else {
                allProducts.firstOrNull { it.code.isNotBlank() && it.code == code }
            }
            base?.let { p ->
                p.copy(
                    san = store.sanPrice(p),
                    zorro = store.zorroPrice(p)
                )
            }
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = ticketUri
        val target = ticketTarget
        if (success && uri != null && target != null) {
            processingReceipt = true
            receiptMessage = "Leyendo ticket..."
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { visionText ->
                        val items = buildReceiptItems(visionText.text, allProducts, store)
                        receiptItems = items
                        processingReceipt = false
                        val autoMatched = items.count { it.productId != null && it.score >= 0.60 }
                        receiptMessage = if (items.isEmpty()) {
                            "No pude identificar renglones con precio. Toma otra foto más cerca y con buena luz."
                        } else {
                            "Detecté ${items.size} renglón(es) con precio. Relacionados automáticamente: $autoMatched. Puedes asignar manualmente los demás y la app lo recordará para próximos tickets."
                        }
                        showReceiptReview = true
                    }
                    .addOnFailureListener {
                        processingReceipt = false
                        receiptMessage = "No pude leer el ticket. Intenta tomar la foto nuevamente."
                        showReceiptReview = true
                    }
            } catch (_: Exception) {
                processingReceipt = false
                receiptMessage = "No pude abrir la foto del ticket."
                showReceiptReview = true
            }
        }
    }

    fun searchAnother() {
        if (code.isNotBlank()) ignoredCode = code
        code = ""
        showAssign = false
        showNewProduct = false
        showEditPrices = null
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Comparador de Precios", style = MaterialTheme.typography.headlineSmall)
        Text("Versión 4.3", style = MaterialTheme.typography.bodySmall)
        Text("Escanea un código para comparar San Antonio vs. El Zorro.")

        receiptMessage?.let { message ->
            Card(Modifier.fillMaxWidth()) {
                Text(message, Modifier.padding(12.dp))
            }
        }

        if (cameraGranted) {
            BarcodeScanner { scanned ->
                if (scanned.isBlank()) return@BarcodeScanner
                if (scanned == ignoredCode) return@BarcodeScanner
                if (ignoredCode != null && scanned != ignoredCode) ignoredCode = null
                if (scanned != code) code = scanned
            }
        } else {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Autoriza la cámara para escanear códigos de barras.")
                    Button(onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("Autorizar cámara")
                    }
                }
            }
        }

        // El botón de ticket va DESPUÉS de la vista de cámara.
        // Así ninguna superficie nativa de CameraX puede dibujarse encima de él.
        Button(
            onClick = { showTicketStore = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (processingReceipt) "Leyendo ticket..." else "Tomar foto de ticket")
        }

        OutlinedTextField(
            value = code,
            onValueChange = {
                ignoredCode = null
                code = it.trim()
            },
            label = { Text("Código de barras") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (code.isNotBlank() && result == null) {
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Código no encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Código: $code")
                    Text("La primera vez debes asociar este código con el producto. Después la app lo recordará.")
                    Button(onClick = { showAssign = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Registrar producto")
                    }
                    OutlinedButton(
                        onClick = { searchAnother() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Buscar otro artículo")
                    }
                }
            }
        }

        result?.let { p ->
            ProductCard(
                product = p,
                code = code,
                onEditPrices = { showEditPrices = p },
                onChangeProduct = { showAssign = true },
                onSearchAnother = { searchAnother() }
            )
        }

        Spacer(Modifier.height(40.dp))
    }

    if (showAssign && code.isNotBlank()) {
        AssignProductDialog(
            barcode = code,
            products = allProducts.map { p ->
                p.copy(san = store.sanPrice(p), zorro = store.zorroPrice(p))
            },
            onDismiss = { showAssign = false },
            onAssign = { product ->
                store.assignCode(code, product.id)
                showAssign = false
                dataVersion++
            },
            onCreateNew = {
                showAssign = false
                showNewProduct = true
            }
        )
    }

    if (showNewProduct && code.isNotBlank()) {
        NewProductDialog(
            barcode = code,
            onDismiss = { showNewProduct = false },
            onSave = { name, san, zorro ->
                store.createProduct(code, name, san, zorro)
                showNewProduct = false
                dataVersion++
            }
        )
    }

    showEditPrices?.let { product ->
        EditPricesDialog(
            product = product,
            onDismiss = { showEditPrices = null },
            onSave = { san, zorro ->
                store.savePrices(product.id, san, zorro)
                showEditPrices = null
                dataVersion++
            }
        )
    }

    if (showTicketStore) {
        TicketStoreDialog(
            onDismiss = { showTicketStore = false },
            onSelect = { target ->
                showTicketStore = false
                ticketTarget = target
                receiptMessage = null
                val uri = createTicketPhotoUri(context)
                ticketUri = uri
                photoLauncher.launch(uri)
            }
        )
    }

    if (showReceiptReview) {
        ReceiptReviewDialog(
            target = ticketTarget,
            items = receiptItems,
            message = receiptMessage,
            onDismiss = { showReceiptReview = false },
            onAssign = { index -> assigningReceiptIndex = index },
            onApply = { selected ->
                val productsById = allProducts.associateBy { it.id }
                selected.forEach { item ->
                    item.productId?.let { productId ->
                        productsById[productId]?.let { product ->
                            store.saveTicketPrice(product, ticketTarget ?: PriceTarget.SAN_ANTONIO, item.price)
                        }
                    }
                }
                dataVersion++
                receiptMessage = "Se actualizaron ${selected.size} precio(s) desde el ticket."
                showReceiptReview = false
            }
        )
    }

    assigningReceiptIndex?.let { index ->
        val item = receiptItems.getOrNull(index)
        if (item != null) {
            ReceiptProductPickerDialog(
                receiptItem = item,
                products = allProducts,
                onDismiss = { assigningReceiptIndex = null },
                onAssign = { product ->
                    store.saveReceiptAlias(item.description, product.id)
                    receiptItems = receiptItems.toMutableList().also { list ->
                        list[index] = item.copy(
                            productId = product.id,
                            productName = product.name,
                            score = 1.0
                        )
                    }
                    assigningReceiptIndex = null
                }
            )
        } else {
            assigningReceiptIndex = null
        }
    }
}

@Composable
fun ProductCard(
    product: Product,
    code: String,
    onEditPrices: () -> Unit,
    onChangeProduct: () -> Unit,
    onSearchAnother: () -> Unit
) {
    val a = product.san.toDoubleOrNull()
    val z = product.zorro.toDoubleOrNull()

    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleLarge)
            Text("Código: $code")
            Text("San Antonio: ${formatPrice(product.san)}")
            Text("El Zorro (archivo): ${formatPrice(product.zorro)}")

            if (a != null && z != null) {
                val diff = abs(a - z)
                Text("Diferencia: ${money(diff)}")
                Text(
                    when {
                        a < z -> "Conviene San Antonio · Ahorras ${money(diff)}"
                        z < a -> "Conviene El Zorro · Ahorras ${money(diff)}"
                        else -> "Mismo precio"
                    },
                    style = MaterialTheme.typography.titleMedium
                )
            } else {
                Text("Falta al menos un precio para hacer la comparación completa.")
            }

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onEditPrices, modifier = Modifier.weight(1f)) {
                    Text("Editar precios")
                }
                OutlinedButton(onClick = onChangeProduct, modifier = Modifier.weight(1f)) {
                    Text("Cambiar producto")
                }
            }
            OutlinedButton(
                onClick = onSearchAnother,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Buscar otro artículo")
            }
        }
    }
}

@Composable
fun AssignProductDialog(
    barcode: String,
    products: List<Product>,
    onDismiss: () -> Unit,
    onAssign: (Product) -> Unit,
    onCreateNew: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(search, products) {
        val q = search.trim()
        if (q.isBlank()) products.take(30)
        else products.filter { it.name.contains(q, ignoreCase = true) }.take(60)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar código $barcode") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Busca el producto y tócalo para asociar este código.")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Buscar producto") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = onCreateNew,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Crear producto nuevo")
                }
                Text("Productos encontrados: ${filtered.size}")
                LazyColumn(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 330.dp)
                ) {
                    items(filtered, key = { it.id }) { product ->
                        OutlinedButton(
                            onClick = { onAssign(product) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(product.name)
                                Text(
                                    "San Antonio: ${formatPrice(product.san)} · Zorro: ${formatPrice(product.zorro)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) {
                    Text("No se encontró. Usa 'Crear producto nuevo'.")
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun NewProductDialog(
    barcode: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var san by remember { mutableStateOf("") }
    var zorro by remember { mutableStateOf("") }
    val validSan = san.isBlank() || san.toDoubleOrNull() != null
    val validZorro = zorro.isBlank() || zorro.toDoubleOrNull() != null
    val canSave = name.trim().isNotBlank() && validSan && validZorro

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear producto nuevo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Código: $barcode")
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del producto") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = san,
                    onValueChange = { san = normalizePriceInput(it) },
                    label = { Text("Precio San Antonio (opcional)") },
                    singleLine = true,
                    isError = !validSan,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = zorro,
                    onValueChange = { zorro = normalizePriceInput(it) },
                    label = { Text("Precio El Zorro (opcional)") },
                    singleLine = true,
                    isError = !validZorro,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Puedes dejar un precio vacío y completarlo después.")
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name.trim(), san, zorro) },
                enabled = canSave
            ) {
                Text("Guardar producto")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun EditPricesDialog(
    product: Product,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var san by remember(product.id) { mutableStateOf(product.san) }
    var zorro by remember(product.id) { mutableStateOf(product.zorro) }
    val validSan = san.isBlank() || san.toDoubleOrNull() != null
    val validZorro = zorro.isBlank() || zorro.toDoubleOrNull() != null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar precios") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(product.name)
                OutlinedTextField(
                    value = san,
                    onValueChange = { san = normalizePriceInput(it) },
                    label = { Text("Precio San Antonio") },
                    singleLine = true,
                    isError = !validSan,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = zorro,
                    onValueChange = { zorro = normalizePriceInput(it) },
                    label = { Text("Precio El Zorro") },
                    singleLine = true,
                    isError = !validZorro,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!validSan || !validZorro) {
                    Text("Usa solo números y punto decimal, por ejemplo 85.50.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(san, zorro) },
                enabled = validSan && validZorro
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun TicketStoreDialog(
    onDismiss: () -> Unit,
    onSelect: (PriceTarget) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Foto de ticket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("¿De qué tienda es el ticket? Los precios detectados se guardarán en esa columna.")
                Button(onClick = { onSelect(PriceTarget.SAN_ANTONIO) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ticket de San Antonio")
                }
                OutlinedButton(onClick = { onSelect(PriceTarget.EL_ZORRO) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ticket de El Zorro")
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ReceiptReviewDialog(
    target: PriceTarget?,
    items: List<ReceiptItem>,
    message: String?,
    onDismiss: () -> Unit,
    onAssign: (Int) -> Unit,
    onApply: (List<ReceiptItem>) -> Unit
) {
    var selected by remember(items) {
        mutableStateOf(
            items.indices.filter { index ->
                val item = items[index]
                item.productId != null && item.score >= 0.60
            }.toSet()
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Precios detectados · ${target?.label ?: "Ticket"}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                message?.let { Text(it) }
                Text("Revisa los renglones. Si un nombre abreviado no coincide, toca 'Asignar producto'. Esa relación quedará aprendida para los siguientes tickets.")
                if (items.isNotEmpty()) {
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                        items(items.indices.toList()) { index ->
                            val item = items[index]
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Column(
                                    Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Checkbox(
                                            checked = index in selected,
                                            enabled = item.productId != null,
                                            onCheckedChange = { checked ->
                                                selected = if (checked) selected + index else selected - index
                                            }
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                item.productName ?: "Sin producto asociado",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text("Precio detectado: ${formatPrice(item.price)}")
                                            Text("Ticket: ${item.rawLine}", style = MaterialTheme.typography.bodySmall)
                                            if (item.productId != null && item.score < 0.60) {
                                                Text("Coincidencia dudosa: confirma o cambia el producto.", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = { onAssign(index) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (item.productId == null) "Asignar producto" else "Cambiar producto")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(items.filterIndexed { index, _ -> index in selected }) },
                enabled = selected.isNotEmpty()
            ) {
                Text("Aplicar precios")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ReceiptProductPickerDialog(
    receiptItem: ReceiptItem,
    products: List<Product>,
    onDismiss: () -> Unit,
    onAssign: (Product) -> Unit
) {
    var search by remember(receiptItem.rawLine) { mutableStateOf("") }
    val filtered = remember(search, products) {
        val q = search.trim()
        if (q.isBlank()) products.take(35)
        else products.filter { it.name.contains(q, ignoreCase = true) }.take(70)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Asignar producto del ticket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ticket: ${receiptItem.rawLine}")
                Text("Precio: ${formatPrice(receiptItem.price)}")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Buscar producto") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 330.dp)) {
                    items(filtered, key = { it.id }) { product ->
                        OutlinedButton(
                            onClick = { onAssign(product) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Text(product.name, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

private fun createTicketPhotoUri(context: Context): Uri {
    val directory = File(context.cacheDir, "tickets").apply { mkdirs() }
    val file = File.createTempFile("ticket_", ".jpg", directory)
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun buildReceiptItems(
    text: String,
    products: List<Product>,
    store: LocalStore
): List<ReceiptItem> {
    val priceRegex = Regex("(?:\\$\\s*)?(\\d{1,5}(?:[.,]\\d{2}))\\s*$")
    val excluded = listOf(
        "total", "subtotal", "cambio", "efectivo", "tarjeta", "iva", "pago", "ahorro",
        "importe", "saldo", "recibido", "descuento"
    )
    val parsed = mutableListOf<Pair<String, Pair<String, String>>>()
    var previousDescription: String? = null

    text.lineSequence().forEach { raw ->
        val line = raw.trim()
        if (line.isBlank()) return@forEach
        val lower = line.lowercase(Locale.ROOT)
        if (excluded.any { lower.contains(it) }) {
            previousDescription = null
            return@forEach
        }

        val priceMatch = priceRegex.find(line)
        if (priceMatch != null) {
            val price = priceMatch.groupValues[1].replace(',', '.')
            val number = price.toDoubleOrNull()
            if (number == null || number <= 0.0 || number > 100000.0) return@forEach

            var description = line.substring(0, priceMatch.range.first).trim(' ', '-', ':', '.', '*')
            if (description.length < 3) {
                description = previousDescription.orEmpty()
            }
            if (description.length >= 3) {
                parsed += line to (description to price)
            }
            previousDescription = null
        } else if (line.length >= 3 && line.any(Char::isLetter)) {
            previousDescription = line
        }
    }

    val dedup = linkedMapOf<String, ReceiptItem>()
    parsed.forEach { (rawLine, pair) ->
        val (description, price) = pair
        val aliasId = store.receiptAlias(description)
        val aliasProduct = aliasId?.let { id -> products.firstOrNull { it.id == id } }
        val candidate = if (aliasProduct != null) {
            aliasProduct to 1.0
        } else {
            findBestProduct(description, products)
        }

        val item = ReceiptItem(
            rawLine = rawLine,
            description = description,
            price = price,
            productId = candidate?.first?.id,
            productName = candidate?.first?.name,
            score = candidate?.second ?: 0.0
        )
        val key = "${receiptAliasKey(description)}|$price"
        dedup[key] = item
    }

    return dedup.values.toList()
}

private fun findBestProduct(description: String, products: List<Product>): Pair<Product, Double>? {
    val descTokens = matchTokens(description)
    if (descTokens.isEmpty()) return null

    var best: Product? = null
    var bestScore = 0.0
    var bestMatched = 0
    var bestStrong = false

    for (product in products) {
        val productTokens = matchTokens(product.name)
        if (productTokens.isEmpty()) continue
        var matched = 0
        var strong = false
        descTokens.forEach { d ->
            val hit = productTokens.firstOrNull { p ->
                p == d ||
                    (p.length >= 4 && d.length >= 4 && (p.startsWith(d) || d.startsWith(p))) ||
                    (p.length >= 6 && d.length >= 6 && (p.contains(d) || d.contains(p)))
            }
            if (hit != null) {
                matched++
                if (d.length >= 5 || hit.length >= 5) strong = true
            }
        }
        val denominator = minOf(descTokens.size, productTokens.size).coerceAtLeast(1)
        var score = matched.toDouble() / denominator.toDouble()
        val descNorm = receiptAliasKey(description)
        val productNorm = receiptAliasKey(product.name)
        if (descNorm.length >= 5 && productNorm.contains(descNorm)) score += 0.25
        if (productNorm.length >= 5 && descNorm.contains(productNorm)) score += 0.25
        score = score.coerceAtMost(1.0)

        if (score > bestScore) {
            bestScore = score
            bestMatched = matched
            bestStrong = strong
            best = product
        }
    }

    val enough = best != null && (
        bestScore >= 0.60 ||
            (bestScore >= 0.45 && bestMatched >= 2) ||
            (bestScore >= 0.38 && bestMatched >= 1 && bestStrong)
        )
    return if (enough) best!! to bestScore else null
}

private fun receiptAliasKey(value: String): String {
    val normalized = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
    return normalized.take(120)
}

private fun matchTokens(value: String): List<String> {
    val normalized = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
    val ignored = setOf(
        "cj", "caja", "paq", "paquete", "pzs", "pza", "pzas", "gr", "kg", "ml", "lt", "lts",
        "con", "sin", "para", "del", "las", "los", "una", "uno", "por"
    )
    return normalized.split(Regex("\\s+"))
        .map { it.trim() }
        .filter { it.length >= 3 && it !in ignored && !it.all(Char::isDigit) }
}

private fun normalizePriceInput(value: String): String = value.replace(',', '.').filter {
    it.isDigit() || it == '.'
}

private fun formatPrice(value: String): String {
    val number = value.toDoubleOrNull() ?: return "Sin precio"
    return money(number)
}

private fun money(value: Double): String = String.format(Locale.US, "\$%.2f", value)

@Composable
fun BarcodeScanner(onScan: (String) -> Unit) {
    val context = LocalContext.current

    AndroidView(
        factory = { ctx ->
            val view = PreviewView(ctx).apply {
                // Usa TextureView para respetar el orden de capas de Compose.
                // Evita que la vista de cámara se dibuje encima de botones y diálogos.
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            val provider = ProcessCameraProvider.getInstance(ctx)
            provider.addListener({
                val cameraProvider = provider.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = view.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val scanner = BarcodeScanning.getClient()
                val executor = Executors.newSingleThreadExecutor()

                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media != null) {
                        scanner.process(
                            InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        )
                            .addOnSuccessListener { codes ->
                                codes.firstOrNull()?.rawValue?.let(onScan)
                            }
                            .addOnCompleteListener { proxy.close() }
                    } else {
                        proxy.close()
                    }
                }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    context as ComponentActivity,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            }, ContextCompat.getMainExecutor(ctx))
            view
        },
        modifier = Modifier.fillMaxWidth().height(210.dp)
    )
}
