package com.example.comparador

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

data class Product(
    val id: String,
    val code: String,
    val name: String,
    val san: String,
    val zorro: String
)

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("comparador_local", Context.MODE_PRIVATE)

    fun productIdForCode(code: String): String? = prefs.getString("code_$code", null)

    fun assignCode(code: String, productId: String) {
        prefs.edit().putString("code_$code", productId).apply()
    }

    fun sanPrice(product: Product): String =
        prefs.getString("san_${product.id}", null) ?: product.san

    fun zorroPrice(product: Product): String =
        prefs.getString("zorro_${product.id}", null) ?: product.zorro

    fun savePrices(productId: String, san: String, zorro: String) {
        prefs.edit()
            .putString("san_$productId", san.trim())
            .putString("zorro_$productId", zorro.trim())
            .apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val products = loadProducts()
        setContent {
            App(products)
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    result += current.toString().trim()
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result += current.toString().trim()
        return result
    }

    private fun loadProducts(): List<Product> {
        val out = mutableListOf<Product>()
        assets.open("productos.csv").use { input ->
            BufferedReader(InputStreamReader(input)).useLines { lines ->
                lines.drop(1).forEachIndexed { index, line ->
                    if (line.isBlank()) return@forEachIndexed
                    val p = parseCsvLine(line)
                    if (p.size >= 4 && p[0].isNotBlank()) {
                        out += Product(
                            id = index.toString(),
                            code = p[1].trim(),
                            name = p[0].trim(),
                            san = p[2].trim(),
                            zorro = p[3].trim()
                        )
                    }
                }
            }
        }
        return out
    }
}

@Composable
fun App(products: List<Product>) {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var code by remember { mutableStateOf("") }
    var dataVersion by remember { mutableStateOf(0) }
    var showAssign by remember { mutableStateOf(false) }
    var showEditPrices by remember { mutableStateOf<Product?>(null) }

    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> cameraGranted = granted }

    LaunchedEffect(Unit) {
        if (!cameraGranted) cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    val result = remember(code, dataVersion, products) {
        if (code.isBlank()) null
        else {
            val mappedId = store.productIdForCode(code)
            val base = if (mappedId != null) {
                products.firstOrNull { it.id == mappedId }
            } else {
                products.firstOrNull { it.code.isNotBlank() && it.code == code }
            }
            base?.let { p ->
                p.copy(
                    san = store.sanPrice(p),
                    zorro = store.zorroPrice(p)
                )
            }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Comparador de Precios", style = MaterialTheme.typography.headlineSmall)
        Text("Escanea un código para comparar San Antonio vs. El Zorro.")

        if (cameraGranted) {
            BarcodeScanner { scanned ->
                if (scanned.isNotBlank() && scanned != code) code = scanned
            }
        } else {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Autoriza la cámara para escanear códigos de barras.")
                    Button(onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("Autorizar cámara")
                    }
                }
            }
        }

        OutlinedTextField(
            value = code,
            onValueChange = { code = it.trim() },
            label = { Text("Código de barras") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (code.isNotBlank() && result == null) {
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Código no encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Código: $code")
                    Text("Puedes asociarlo a uno de los productos de tu catálogo.")
                    Button(onClick = { showAssign = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Registrar producto")
                    }
                }
            }
        }

        result?.let { p ->
            ProductCard(
                product = p,
                code = code,
                onEditPrices = { showEditPrices = p },
                onChangeProduct = { showAssign = true }
            )
        }
    }

    if (showAssign && code.isNotBlank()) {
        AssignProductDialog(
            barcode = code,
            products = products.map { p ->
                p.copy(san = store.sanPrice(p), zorro = store.zorroPrice(p))
            },
            onDismiss = { showAssign = false },
            onAssign = { product ->
                store.assignCode(code, product.id)
                showAssign = false
                dataVersion++
            }
        )
    }

    showEditPrices?.let { product ->
        EditPricesDialog(
            product = product,
            onDismiss = { showEditPrices = null },
            onSave = { san, zorro ->
                store.savePrices(product.id, san, zorro)
                showEditPrices = null
                dataVersion++
            }
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    code: String,
    onEditPrices: () -> Unit,
    onChangeProduct: () -> Unit
) {
    val a = product.san.toDoubleOrNull()
    val z = product.zorro.toDoubleOrNull()

    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleLarge)
            Text("Código: $code")
            Text("San Antonio: ${formatPrice(product.san)}")
            Text("El Zorro (archivo): ${formatPrice(product.zorro)}")

            if (a != null && z != null) {
                val diff = abs(a - z)
                Text("Diferencia: ${money(diff)}")
                Text(
                    when {
                        a < z -> "Conviene San Antonio · Ahorras ${money(diff)}"
                        z < a -> "Conviene El Zorro · Ahorras ${money(diff)}"
                        else -> "Mismo precio"
                    },
                    style = MaterialTheme.typography.titleMedium
                )
            } else {
                Text("Falta al menos un precio para hacer la comparación completa.")
            }

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onEditPrices, modifier = Modifier.weight(1f)) {
                    Text("Editar precios")
                }
                OutlinedButton(onClick = onChangeProduct, modifier = Modifier.weight(1f)) {
                    Text("Cambiar producto")
                }
            }
        }
    }
}

@Composable
fun AssignProductDialog(
    barcode: String,
    products: List<Product>,
    onDismiss: () -> Unit,
    onAssign: (Product) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(search, products) {
        val q = search.trim()
        if (q.isBlank()) products.take(30)
        else products.filter { it.name.contains(q, ignoreCase = true) }.take(40)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar código $barcode") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Busca el producto y tócalo para asociar este código.")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Buscar producto") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                    items(filtered, key = { it.id }) { product ->
                        OutlinedButton(
                            onClick = { onAssign(product) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(product.name)
                                Text(
                                    "San Antonio: ${formatPrice(product.san)} · Zorro: ${formatPrice(product.zorro)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) Text("No se encontraron productos con ese nombre.")
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun EditPricesDialog(
    product: Product,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var san by remember(product.id) { mutableStateOf(product.san) }
    var zorro by remember(product.id) { mutableStateOf(product.zorro) }
    val validSan = san.isBlank() || san.toDoubleOrNull() != null
    val validZorro = zorro.isBlank() || zorro.toDoubleOrNull() != null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar precios") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(product.name)
                OutlinedTextField(
                    value = san,
                    onValueChange = { san = normalizePriceInput(it) },
                    label = { Text("Precio San Antonio") },
                    singleLine = true,
                    isError = !validSan,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = zorro,
                    onValueChange = { zorro = normalizePriceInput(it) },
                    label = { Text("Precio El Zorro") },
                    singleLine = true,
                    isError = !validZorro,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!validSan || !validZorro) {
                    Text("Usa solo números y punto decimal, por ejemplo 85.50.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(san, zorro) },
                enabled = validSan && validZorro
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

private fun normalizePriceInput(value: String): String = value.replace(',', '.').filter {
    it.isDigit() || it == '.'
}

private fun formatPrice(value: String): String {
    val number = value.toDoubleOrNull() ?: return "Sin precio"
    return money(number)
}

private fun money(value: Double): String = String.format(Locale.US, "\$%.2f", value)

@Composable
fun BarcodeScanner(onScan: (String) -> Unit) {
    val context = LocalContext.current

    AndroidView(
        factory = { ctx ->
            val view = PreviewView(ctx)
            val provider = ProcessCameraProvider.getInstance(ctx)
            provider.addListener({
                val cameraProvider = provider.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = view.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val scanner = BarcodeScanning.getClient()
                val executor = Executors.newSingleThreadExecutor()

                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media != null) {
                        scanner.process(
                            InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        )
                            .addOnSuccessListener { codes ->
                                codes.firstOrNull()?.rawValue?.let(onScan)
                            }
                            .addOnCompleteListener { proxy.close() }
                    } else {
                        proxy.close()
                    }
                }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    context as ComponentActivity,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            }, ContextCompat.getMainExecutor(ctx))
            view
        },
        modifier = Modifier.fillMaxWidth().height(260.dp)
    )
}
