package com.example.comparador

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

// CSV columns: producto,codigo_barras,precio_san_antonio,precio_el_zorro,diferencia,mejor_precio
data class Product(val code:String,val name:String,val san:String,val zorro:String)

class MainActivity: ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        // UI will recompose when the activity resumes; no action needed here.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.CAMERA)
        }
        setContent { App(loadProducts()) }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        for (c in line) {
            when {
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { result += current.toString().trim(); current.clear() }
                else -> current.append(c)
            }
        }
        result += current.toString().trim()
        return result
    }

    private fun loadProducts(): List<Product> {
        val out = mutableListOf<Product>()
        assets.open("productos.csv").use { input ->
            BufferedReader(InputStreamReader(input)).useLines { lines ->
                lines.drop(1).forEach { line ->
                    if (line.isBlank()) return@forEach
                    val p = parseCsvLine(line)
                    if (p.size >= 4) out += Product(p[1], p[0], p[2], p[3])
                }
            }
        }
        return out
    }
}

@Composable
fun App(products: List<Product>) {
    var code by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<Product?>(null) }
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Comparador de Precios", style = MaterialTheme.typography.headlineSmall)
        Text("Escanea un código de barras para comparar San Antonio vs. El Zorro.")

        BarcodeScanner { scanned ->
            code = scanned
            result = products.firstOrNull { it.code == scanned }
        }

        OutlinedTextField(
            value = code,
            onValueChange = { code = it; result = products.firstOrNull { p -> p.code == it } },
            label = { Text("Código de barras") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (code.isNotBlank() && result == null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Código no encontrado")
                    Text("Código: $code")
                    Text("Después podremos asignarlo a un producto.")
                }
            }
        }

        result?.let { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    Text("San Antonio: ${p.san.ifBlank { "Sin precio" }}")
                    Text("El Zorro: ${p.zorro.ifBlank { "Sin precio" }}")
                    val a = p.san.toDoubleOrNull(); val z = p.zorro.toDoubleOrNull()
                    if (a != null && z != null) {
                        val diff = kotlin.math.abs(a - z)
                        Text("Diferencia: ${"%.2f".format(diff)}")
                        Text(
                            if (a < z) "Conviene San Antonio"
                            else if (z < a) "Conviene El Zorro"
                            else "Mismo precio",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeScanner(onScan: (String) -> Unit) {
    val context = LocalContext.current
    val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    if (!hasPermission) {
        Card(Modifier.fillMaxWidth()) {
            Text("Autoriza la cámara para escanear códigos de barras.", Modifier.padding(16.dp))
        }
        return
    }

    AndroidView(
        factory = { ctx ->
            val view = PreviewView(ctx)
            val provider = ProcessCameraProvider.getInstance(ctx)
            provider.addListener({
                val cameraProvider = provider.get()
                val preview = Preview.Builder().build().also { it.surfaceProvider = view.surfaceProvider }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val scanner = BarcodeScanning.getClient()
                val executor = Executors.newSingleThreadExecutor()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media != null) {
                        scanner.process(InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees))
                            .addOnSuccessListener { codes ->
                                codes.firstOrNull()?.rawValue?.let(onScan)
                            }
                            .addOnCompleteListener { proxy.close() }
                    } else proxy.close()
                }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    context as ComponentActivity,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            }, ContextCompat.getMainExecutor(ctx))
            view
        },
        modifier = Modifier.fillMaxWidth().height(260.dp)
    )
}
