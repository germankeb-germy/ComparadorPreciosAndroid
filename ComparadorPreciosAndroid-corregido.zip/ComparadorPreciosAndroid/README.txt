COMPARADOR DE PRECIOS - PROTOTIPO ANDROID

Se creó un proyecto Android Studio en esta carpeta.
Productos cargados desde: Costos_comparador_barcodes.xlsx
Registros exportados al CSV: 130

Función:
- Escaneo de código de barras con la cámara.
- Búsqueda por código.
- Comparación de precio San Antonio vs. El Zorro.
- Entrada manual del código como respaldo.

Para compilar:
1. Abrir la carpeta en Android Studio.
2. Esperar la sincronización de Gradle.
3. Conectar el teléfono Android con depuración USB.
4. Ejecutar la app.

Nota: para usar el comparador en producción habrá que completar los códigos de barras de los productos en el archivo y revisar el formato de precios de cada hoja.
