# Compilar el APK en GitHub

1. Sube este ZIP al repositorio.
2. Crea el archivo `.github/workflows/build-apk.yml` con el contenido indicado por ChatGPT.
3. Abre la pestaña Actions y ejecuta el workflow.
4. Al terminar, descarga el artefacto `comparador-precios-apk` y dentro estará `app-debug.apk`.
