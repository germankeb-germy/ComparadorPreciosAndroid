# Compilar V5.9 en GitHub

Usa el workflow estable que ya configuraste.

Solo cambia la línea de descompresión a:

    unzip -q ComparadorPreciosAndroid-V5.9.zip -d proyecto

Mantén los mismos secretos de firma:
- COMPARADOR_KEYSTORE_BASE64
- COMPARADOR_KEYSTORE_PASSWORD
- COMPARADOR_KEY_ALIAS
- COMPARADOR_KEY_PASSWORD

El APK seguirá usando el mismo applicationId y la misma firma estable.
