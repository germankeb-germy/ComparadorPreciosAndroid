# Comparador de Precios V6.0

Cambios principales:
- OCR de ticket más conservador: evita interpretar folios, cantidades y códigos como precios.
- Usa el último importe monetario del renglón y favorece valores con decimales o símbolo $.
- Recupera el nombre del producto desde renglones anteriores cuando el ticket separa descripción y precio.
- La revisión siempre muestra `Nombre detectado` además del producto asociado del catálogo.
- Mantiene la importación de todas las hojas del Excel y la búsqueda web informativa.
- versionCode 15 / versionName 6.0.

Compilar con el workflow firmado estable ya configurado en GitHub. Cambiar únicamente el nombre del ZIP en `build-apk-fixed.yml` a `ComparadorPreciosAndroid-V6.0.zip`.
