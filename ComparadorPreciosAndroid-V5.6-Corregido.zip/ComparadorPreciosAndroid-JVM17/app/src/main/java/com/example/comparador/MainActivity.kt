package com.example.comparador

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.RowScope
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

data class StoreInfo(
    val key: String,
    val label: String
)

private val PastelColors = lightColorScheme(
    primary = Color(0xFF6B557A),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFFF6D1C1),
    onSecondary = Color(0xFF4B342B),
    tertiary = Color(0xFFBFE3D0),
    onTertiary = Color(0xFF253C31),
    primaryContainer = Color(0xFFEDE3F7),
    onPrimaryContainer = Color(0xFF3A2E46),
    secondaryContainer = Color(0xFFFFE7DD),
    onSecondaryContainer = Color(0xFF4B342B),
    surfaceVariant = Color(0xFFF7F1FA),
    outline = Color(0xFF8B7E93)
)

private val PastelButtonBackground = Color(0xFFDCCCF0)
private val PastelButtonText = Color(0xFF30263A)
private val PastelOutlineBackground = Color(0xFFF7F1FA)
private val PastelOutlineText = Color(0xFF3A2E46)

@Composable
private fun PastelButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    androidx.compose.material3.Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = PastelButtonBackground,
            contentColor = PastelButtonText,
            disabledContainerColor = Color(0xFFEAE2F0),
            disabledContentColor = Color(0xFF6B6170)
        ),
        content = content
    )
}

@Composable
private fun PastelOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = PastelOutlineBackground,
            contentColor = PastelOutlineText,
            disabledContainerColor = Color(0xFFF0EBF3),
            disabledContentColor = Color(0xFF6B6170)
        ),
        content = content
    )
}

val PURCHASE_STORES = listOf(
    StoreInfo("san_antonio", "San Antonio"),
    StoreInfo("el_zorro", "El Zorro"),
    StoreInfo("garis", "Garis"),
    StoreInfo("tetela_manuel", "Tetela Manuel"),
    StoreInfo("tetela_chilero", "Tetela Chilero"),
    StoreInfo("otro", "Otro"),
    StoreInfo("depto_julianos", "Depto. Julianos"),
    StoreInfo("depto_sahro", "Depto. Sahro"),
    StoreInfo("sams_club", "Sam's Club"),
    StoreInfo("bodega_aurrera", "Bodega Aurrera"),
    StoreInfo("cata_yeca", "Cata Yeca"),
    StoreInfo("el_chino", "El Chino"),
    StoreInfo("coca_cola_oficial", "Coca Cola Oficial")
)

data class Product(
    val id: String,
    val code: String,
    val name: String,
    val prices: Map<String, String>,
    val category: String = "",
    val publicPrice: String = "",
    val sourceComments: String = ""
)

data class ReceiptItem(
    val rawLine: String,
    val description: String,
    val price: String,
    val productId: String? = null,
    val productName: String? = null,
    val score: Double = 0.0
)

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("comparador_local", Context.MODE_PRIVATE)

    fun productIdForCode(code: String): String? = prefs.getString("code_$code", null)

    fun assignCode(code: String, productId: String) {
        prefs.edit().putString("code_$code", productId).apply()
    }

    fun price(product: Product, storeKey: String): String {
        val current = prefs.getString("price_${storeKey}_${product.id}", null)
        if (current != null) return current

        // Compatibilidad con versiones anteriores.
        if (storeKey == "san_antonio") {
            val legacy = prefs.getString("san_${product.id}", null)
            if (legacy != null) return legacy
        }
        if (storeKey == "el_zorro") {
            val legacy = prefs.getString("zorro_${product.id}", null)
            if (legacy != null) return legacy
        }
        return product.prices[storeKey].orEmpty()
    }

    private fun appendHistory(productId: String, message: String) {
        val key = "history_$productId"
        val current = try { JSONArray(prefs.getString(key, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        current.put(message)
        // Conserva las últimas 80 entradas por producto para evitar crecimiento ilimitado.
        val trimmed = JSONArray()
        val start = (current.length() - 80).coerceAtLeast(0)
        for (i in start until current.length()) trimmed.put(current.get(i))
        prefs.edit().putString(key, trimmed.toString()).apply()
    }

    fun history(productId: String): List<String> {
        val raw = prefs.getString("history_$productId", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList { for (i in 0 until array.length()) add(array.optString(i)) }
        } catch (_: Exception) { emptyList() }
    }

    fun editableComments(product: Product): String =
        prefs.getString("editable_comments_${product.id}", null) ?: product.sourceComments

    fun publicPrice(product: Product): String =
        prefs.getString("public_price_${product.id}", null) ?: product.publicPrice

    fun savePublicPrice(product: Product, value: String, source: String = "Edición manual") {
        val old = publicPrice(product).trim()
        val newValue = value.trim()
        prefs.edit().putString("public_price_${product.id}", newValue).apply()
        if (old != newValue) {
            val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            appendHistory(
                product.id,
                "$stamp · $source · Precio público Diana: ${old.ifBlank { "sin precio" }} → ${newValue.ifBlank { "sin precio" }}"
            )
        }
    }

    fun saveEditableComments(product: Product, value: String) {
        val oldValue = editableComments(product).trim()
        val newValue = value.trim()
        prefs.edit().putString("editable_comments_${product.id}", newValue).apply()
        if (oldValue != newValue) {
            val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            appendHistory(product.id, "$stamp · Comentarios/historial editados y guardados")
        }
    }

    fun savePrices(product: Product, prices: Map<String, String>, source: String = "Edición manual") {
        val before = allStores().associate { store -> store.key to price(product, store.key) }
        val editor = prefs.edit()
        val changes = mutableListOf<String>()
        allStores().forEach { store ->
            val value = prices[store.key].orEmpty().trim()
            val old = before[store.key].orEmpty().trim()
            editor.putString("price_${store.key}_${product.id}", value)
            if (store.key == "san_antonio") editor.putString("san_${product.id}", value)
            if (store.key == "el_zorro") editor.putString("zorro_${product.id}", value)
            if (old != value) {
                val oldShown = old.ifBlank { "sin precio" }
                val newShown = value.ifBlank { "sin precio" }
                changes += "${store.label}: $oldShown → $newShown"
            }
        }
        editor.apply()
        if (changes.isNotEmpty()) {
            val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            appendHistory(product.id, "$stamp · $source · ${changes.joinToString(" · ")}")
        }
    }

    fun saveTicketPrice(product: Product, storeKey: String, price: String) {
        val updated = allStores().associate { store ->
            store.key to if (store.key == storeKey) price.trim() else this.price(product, store.key)
        }
        savePrices(product, updated, "Ticket")
    }

    fun receiptAlias(description: String): String? =
        prefs.getString("ticket_alias_${receiptAliasKey(description)}", null)

    fun saveReceiptAlias(description: String, productId: String) {
        prefs.edit()
            .putString("ticket_alias_${receiptAliasKey(description)}", productId)
            .apply()
    }

    fun assignedCodes(): Map<String, String> =
        prefs.all.entries.mapNotNull { (key, value) ->
            if (key.startsWith("code_") && value is String) {
                key.removePrefix("code_") to value
            } else null
        }.toMap()

    fun customStores(): List<StoreInfo> {
        val raw = prefs.getString("custom_stores", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val key = o.optString("key")
                    val label = o.optString("label")
                    if (key.isNotBlank() && label.isNotBlank()) add(StoreInfo(key, label))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun allStores(): List<StoreInfo> = PURCHASE_STORES + customStores()

    fun createStore(label: String): StoreInfo {
        val clean = label.trim()
        val base = receiptAliasKey(clean).replace(' ', '_').ifBlank { "tienda" }.take(30)
        val key = "custom_${base}_${System.currentTimeMillis()}"
        val created = StoreInfo(key, clean)
        val stores = customStores().toMutableList().apply { add(created) }
        val arr = JSONArray()
        stores.forEach { arr.put(JSONObject().put("key", it.key).put("label", it.label)) }
        prefs.edit().putString("custom_stores", arr.toString()).apply()
        return created
    }

    fun localProducts(): List<Product> {
        val raw = prefs.getString("local_products", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val prices = linkedMapOf<String, String>()
                    val pricesObject = o.optJSONObject("prices")
                    if (pricesObject != null) {
                        allStores().forEach { store ->
                            prices[store.key] = pricesObject.optString(store.key)
                        }
                    } else {
                        // Compatibilidad con productos creados en V2-V5.
                        prices["san_antonio"] = o.optString("san")
                        prices["el_zorro"] = o.optString("zorro")
                    }
                    add(
                        Product(
                            id = o.optString("id"),
                            code = o.optString("code"),
                            name = o.optString("name"),
                            prices = prices,
                            category = o.optString("category", "Registrado en app"),
                            publicPrice = o.optString("publicPrice"),
                            sourceComments = o.optString("sourceComments")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun createProduct(code: String, name: String, prices: Map<String, String>): Product {
        val product = Product(
            id = "local_${System.currentTimeMillis()}",
            code = code.trim(),
            name = name.trim(),
            prices = allStores().associate { store -> store.key to prices[store.key].orEmpty().trim() },
            category = "Registrado en app",
            sourceComments = ""
        )
        val current = localProducts().toMutableList()
        current += product

        val array = JSONArray()
        current.forEach { p ->
            val priceObject = JSONObject()
            allStores().forEach { store ->
                priceObject.put(store.key, p.prices[store.key].orEmpty())
            }
            array.put(
                JSONObject()
                    .put("id", p.id)
                    .put("code", p.code)
                    .put("name", p.name)
                    .put("prices", priceObject)
                    .put("san", p.prices["san_antonio"].orEmpty())
                    .put("zorro", p.prices["el_zorro"].orEmpty())
                    .put("category", p.category)
                    .put("publicPrice", p.publicPrice)
                    .put("sourceComments", p.sourceComments)
            )
        }
        prefs.edit().putString("local_products", array.toString()).apply()
        assignCode(product.code, product.id)
        return product
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val products = loadProducts()
        setContent {
            MaterialTheme(colorScheme = PastelColors) {
                App(products)
            }
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    result += current.toString().trim()
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result += current.toString().trim()
        return result
    }

    private fun loadProducts(): List<Product> {
        val out = mutableListOf<Product>()
        assets.open("productos.csv").use { input ->
            BufferedReader(InputStreamReader(input)).use { reader ->
                val headerLine = reader.readLine() ?: return@use
                val headers = parseCsvLine(headerLine).map {
                    it.trim().removePrefix("\uFEFF").lowercase(Locale.ROOT)
                }
                val indexByName = headers.withIndex().associate { it.value to it.index }

                reader.lineSequence().forEachIndexed { index, line ->
                    if (line.isBlank()) return@forEachIndexed
                    val p = parseCsvLine(line)
                    fun field(name: String): String {
                        val i = indexByName[name] ?: return ""
                        return p.getOrNull(i)?.trim().orEmpty()
                    }

                    val name = field("producto")
                    if (name.isBlank()) return@forEachIndexed

                    val prices = PURCHASE_STORES.associate { store ->
                        store.key to field(store.key)
                    }

                    out += Product(
                        id = field("id").ifBlank { index.toString() },
                        code = field("codigo_barras"),
                        name = name,
                        prices = prices,
                        category = field("categoria"),
                        publicPrice = field("precio_publico_diana"),
                        sourceComments = field("comentarios_archivo")
                    )
                }
            }
        }
        return out
    }
}

@Composable
fun App(products: List<Product>) {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var code by remember { mutableStateOf("") }
    var ignoredCode by remember { mutableStateOf<String?>(null) }
    var dataVersion by remember { mutableStateOf(0) }
    var showAssign by remember { mutableStateOf(false) }
    var showNewProduct by remember { mutableStateOf(false) }
    var showEditPrices by remember { mutableStateOf<Product?>(null) }
    var showHistoryFor by remember { mutableStateOf<Product?>(null) }
    var showTicketStore by remember { mutableStateOf(false) }
    var showCreateStore by remember { mutableStateOf(false) }
    var ticketTarget by remember { mutableStateOf<StoreInfo?>(null) }
    var ticketUri by remember { mutableStateOf<Uri?>(null) }
    var receiptItems by remember { mutableStateOf<List<ReceiptItem>>(emptyList()) }
    var assigningReceiptIndex by remember { mutableStateOf<Int?>(null) }
    var showReceiptReview by remember { mutableStateOf(false) }
    var receiptMessage by remember { mutableStateOf<String?>(null) }
    var processingReceipt by remember { mutableStateOf(false) }

    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> cameraGranted = granted }

    LaunchedEffect(Unit) {
        if (!cameraGranted) cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    val allProducts = remember(dataVersion, products) {
        products + store.localProducts()
    }
    val allStores = remember(dataVersion) { store.allStores() }

    LaunchedEffect(dataVersion, allProducts.size) {
        writeArticleBarcodeFile(context, allProducts, store)
        writeUpdatedCostsFile(context, allProducts, store)
    }

    val result = remember(code, dataVersion, allProducts) {
        if (code.isBlank()) null
        else {
            val mappedId = store.productIdForCode(code)
            val base = if (mappedId != null) {
                allProducts.firstOrNull { it.id == mappedId }
            } else {
                allProducts.firstOrNull { it.code.isNotBlank() && it.code == code }
            }
            base?.let { p ->
                p.copy(
                    prices = allStores.associate { storeInfo ->
                        storeInfo.key to store.price(p, storeInfo.key)
                    },
                    publicPrice = store.publicPrice(p)
                )
            }
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = ticketUri
        val target = ticketTarget
        if (success && uri != null && target != null) {
            processingReceipt = true
            receiptMessage = "Leyendo ticket..."
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { visionText ->
                        val items = buildReceiptItems(visionText.text, allProducts, store)
                        receiptItems = items
                        processingReceipt = false
                        val autoMatched = items.count { it.productId != null && it.score >= 0.60 }
                        receiptMessage = if (items.isEmpty()) {
                            "No pude identificar renglones con precio. Toma otra foto más cerca y con buena luz."
                        } else {
                            "Detecté ${items.size} renglón(es) con precio. Relacionados automáticamente: $autoMatched. Puedes asignar manualmente los demás y la app lo recordará para próximos tickets."
                        }
                        showReceiptReview = true
                    }
                    .addOnFailureListener {
                        processingReceipt = false
                        receiptMessage = "No pude leer el ticket. Intenta tomar la foto nuevamente."
                        showReceiptReview = true
                    }
            } catch (_: Exception) {
                processingReceipt = false
                receiptMessage = "No pude abrir la foto del ticket."
                showReceiptReview = true
            }
        }
    }

    fun searchAnother() {
        if (code.isNotBlank()) ignoredCode = code
        code = ""
        showAssign = false
        showNewProduct = false
        showEditPrices = null
        showHistoryFor = null
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Comparador de Precios", style = MaterialTheme.typography.headlineSmall)
        Text("Versión 5.6 · escáner compacto + ticket revisable + tiendas", style = MaterialTheme.typography.bodySmall)
        Text("Escanea un código para ver todos los precios disponibles y encontrar la mejor compra.")

        receiptMessage?.let { message ->
            Card(Modifier.fillMaxWidth()) {
                Text(message, Modifier.padding(12.dp))
            }
        }

        if (cameraGranted && code.isBlank() && !showTicketStore && !showCreateStore && !processingReceipt && !showReceiptReview && assigningReceiptIndex == null) {
            BarcodeScanner { scanned ->
                if (scanned.isBlank()) return@BarcodeScanner
                if (scanned == ignoredCode) return@BarcodeScanner
                if (ignoredCode != null && scanned != ignoredCode) ignoredCode = null
                playScanBeep(context)
                code = scanned
            }
        } else if (!cameraGranted) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Autoriza la cámara para escanear códigos de barras.")
                    PastelButton(onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("Autorizar cámara")
                    }
                }
            }
        }

        // El botón de ticket va DESPUÉS de la vista de cámara.
        // Así ninguna superficie nativa de CameraX puede dibujarse encima de él.
        PastelButton(
            onClick = { showTicketStore = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (processingReceipt) "Leyendo ticket..." else "Tomar foto de ticket · elegir tienda")
        }

        PastelOutlinedButton(
            onClick = { shareArticleBarcodeFile(context, allProducts, store) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Exportar artículos y códigos")
        }

        PastelOutlinedButton(
            onClick = { shareUpdatedCostsFile(context, allProducts, store) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Exportar costos actualizados")
        }

        OutlinedTextField(
            value = code,
            onValueChange = {
                ignoredCode = null
                code = it.trim()
            },
            label = { Text("Código de barras") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (code.isNotBlank() && result == null) {
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Código no encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Código: $code")
                    Text("La primera vez debes asociar este código con el producto. Después la app lo recordará.")
                    PastelButton(onClick = { showAssign = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Registrar producto")
                    }
                    PastelOutlinedButton(
                        onClick = { searchAnother() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Buscar otro artículo")
                    }
                }
            }
        }

        result?.let { p ->
            ProductCard(
                product = p,
                code = code,
                stores = allStores,
                onEditPrices = { showEditPrices = p },
                onChangeProduct = { showAssign = true },
                onSaveProduct = {
                    store.assignCode(code, p.id)
                    dataVersion++
                    Toast.makeText(context, "Producto y código guardados", Toast.LENGTH_SHORT).show()
                },
                onShowHistory = { showHistoryFor = p },
                onSearchAnother = { searchAnother() }
            )
        }

        Spacer(Modifier.height(40.dp))
    }

    if (showAssign && code.isNotBlank()) {
        AssignProductDialog(
            barcode = code,
            products = allProducts.map { p ->
                p.copy(
                    prices = allStores.associate { storeInfo ->
                        storeInfo.key to store.price(p, storeInfo.key)
                    }
                )
            },
            onDismiss = { showAssign = false },
            onAssign = { product ->
                store.assignCode(code, product.id)
                showAssign = false
                dataVersion++
                Toast.makeText(context, "Producto y código guardados", Toast.LENGTH_SHORT).show()
            },
            onCreateNew = {
                showAssign = false
                showNewProduct = true
            }
        )
    }

    if (showNewProduct && code.isNotBlank()) {
        NewProductDialog(
            barcode = code,
            stores = allStores,
            onDismiss = { showNewProduct = false },
            onSave = { name, prices ->
                store.createProduct(code, name, prices)
                showNewProduct = false
                dataVersion++
            }
        )
    }

    showEditPrices?.let { product ->
        EditPricesDialog(
            product = product,
            stores = allStores,
            onDismiss = { showEditPrices = null },
            onSave = { prices, publicPrice ->
                store.savePrices(product, prices, "Edición manual")
                store.savePublicPrice(product, publicPrice, "Edición manual")
                showEditPrices = null
                dataVersion++
                Toast.makeText(context, "Precios y precio Diana guardados", Toast.LENGTH_SHORT).show()
            }
        )
    }

    showHistoryFor?.let { product ->
        HistoryDialog(
            product = product,
            appHistory = store.history(product.id),
            editableComments = store.editableComments(product),
            onDismiss = { showHistoryFor = null },
            onSave = { updatedComments ->
                store.saveEditableComments(product, updatedComments)
                dataVersion++
                showHistoryFor = null
                Toast.makeText(context, "Historial/comentarios guardados", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showTicketStore) {
        TicketStoreDialog(
            stores = allStores,
            onDismiss = { showTicketStore = false },
            onCreateStore = { showTicketStore = false; showCreateStore = true },
            onSelect = { target ->
                showTicketStore = false
                ticketTarget = target
                receiptMessage = null
                val uri = createTicketPhotoUri(context)
                ticketUri = uri
                photoLauncher.launch(uri)
            }
        )
    }

    if (showCreateStore) {
        CreateStoreDialog(
            onDismiss = { showCreateStore = false },
            onCreate = { label ->
                val created = store.createStore(label)
                dataVersion++
                showCreateStore = false
                showTicketStore = false
                ticketTarget = created
                receiptMessage = null
                val uri = createTicketPhotoUri(context)
                ticketUri = uri
                photoLauncher.launch(uri)
            }
        )
    }

    if (showReceiptReview) {
        ReceiptReviewDialog(
            target = ticketTarget,
            items = receiptItems,
            message = receiptMessage,
            onDismiss = { showReceiptReview = false },
            onAssign = { index -> assigningReceiptIndex = index },
            onApply = { selected ->
                val productsById = allProducts.associateBy { it.id }
                selected.forEach { item ->
                    item.productId?.let { productId ->
                        productsById[productId]?.let { product ->
                            store.saveTicketPrice(product, ticketTarget?.key ?: "san_antonio", item.price)
                        }
                    }
                }
                dataVersion++
                receiptMessage = "Se actualizaron ${selected.size} precio(s) desde el ticket."
                showReceiptReview = false
            }
        )
    }

    assigningReceiptIndex?.let { index ->
        val item = receiptItems.getOrNull(index)
        if (item != null) {
            ReceiptProductPickerDialog(
                receiptItem = item,
                products = allProducts,
                onDismiss = { assigningReceiptIndex = null },
                onAssign = { product ->
                    store.saveReceiptAlias(item.description, product.id)
                    receiptItems = receiptItems.toMutableList().also { list ->
                        list[index] = item.copy(
                            productId = product.id,
                            productName = product.name,
                            score = 1.0
                        )
                    }
                    assigningReceiptIndex = null
                }
            )
        } else {
            assigningReceiptIndex = null
        }
    }
}

private fun availableStorePrices(product: Product, stores: List<StoreInfo>): List<Triple<StoreInfo, String, Double>> =
    stores.mapNotNull { store ->
        val raw = product.prices[store.key].orEmpty()
        val number = raw.toDoubleOrNull()
        if (number != null) Triple(store, raw, number) else null
    }

private fun priceSummary(product: Product): String {
    val available = availableStorePrices(product, PURCHASE_STORES)
    if (available.isEmpty()) return "Sin precios registrados"
    val shown = available.take(3).joinToString(" · ") { (store, raw, _) ->
        "${store.label}: ${formatPrice(raw)}"
    }
    return if (available.size > 3) "$shown · +${available.size - 3} más" else shown
}

@Composable
fun ProductCard(
    product: Product,
    code: String,
    stores: List<StoreInfo>,
    onEditPrices: () -> Unit,
    onChangeProduct: () -> Unit,
    onSaveProduct: () -> Unit,
    onShowHistory: () -> Unit,
    onSearchAnother: () -> Unit
) {
    val available = availableStorePrices(product, stores)
    val best = available.minByOrNull { it.third }
    val highest = available.maxByOrNull { it.third }

    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleLarge)
            if (product.category.isNotBlank()) {
                Text("Categoría: ${product.category}", style = MaterialTheme.typography.bodySmall)
            }
            Text("Código: $code")

            if (available.isEmpty()) {
                Text("Este artículo está en el catálogo, pero todavía no tiene precios registrados.")
            } else {
                Text("Precios disponibles", style = MaterialTheme.typography.titleMedium)
                available.forEach { (store, raw, _) ->
                    Text("${store.label}: ${formatPrice(raw)}")
                }

                if (available.size == 1) {
                    val only = available.first()
                    Text(
                        "Único precio disponible: ${only.first.label} · ${formatPrice(only.second)}",
                        style = MaterialTheme.typography.titleMedium
                    )
                } else if (best != null && highest != null) {
                    Text(
                        "Mejor compra: ${best.first.label} · ${formatPrice(best.second)}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    val saving = highest.third - best.third
                    if (saving > 0.0) {
                        Text("Diferencia contra el precio más alto: ${money(saving)}")
                    }
                }
            }

            if (product.publicPrice.toDoubleOrNull() != null) {
                Text("Precio público Diana: ${formatPrice(product.publicPrice)}")
            }

            Spacer(Modifier.height(4.dp))
            PastelButton(
                onClick = onSaveProduct,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar producto")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PastelButton(onClick = onEditPrices, modifier = Modifier.weight(1f)) {
                    Text("Editar precios")
                }
                PastelOutlinedButton(onClick = onChangeProduct, modifier = Modifier.weight(1f)) {
                    Text("Cambiar producto")
                }
            }
            PastelOutlinedButton(
                onClick = onShowHistory,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Historial y comentarios")
            }
            PastelOutlinedButton(
                onClick = onSearchAnother,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Buscar otro artículo")
            }
        }
    }
}

@Composable
fun HistoryDialog(
    product: Product,
    appHistory: List<String>,
    editableComments: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var notes by remember(product.id, editableComments) { mutableStateOf(editableComments) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Historial y comentarios") },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(product.name, style = MaterialTheme.typography.titleMedium)

                if (product.sourceComments.isNotBlank()) {
                    Text("Comentario original del archivo Costos", style = MaterialTheme.typography.titleSmall)
                    product.sourceComments.split(" || ").filter { it.isNotBlank() }.forEach { line ->
                        Text("• $line")
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Comentarios / historial editable") },
                    supportingText = { Text("Puedes modificar estas notas y guardarlas en la app.") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )

                if (appHistory.isNotEmpty()) {
                    Text("Cambios registrados automáticamente", style = MaterialTheme.typography.titleSmall)
                    appHistory.asReversed().forEach { line ->
                        Text("• $line")
                    }
                } else {
                    Text("Todavía no hay cambios automáticos registrados.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            PastelButton(onClick = { onSave(notes) }) {
                Text("Guardar cambios")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}

@Composable
fun AssignProductDialog(
    barcode: String,
    products: List<Product>,
    onDismiss: () -> Unit,
    onAssign: (Product) -> Unit,
    onCreateNew: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(search, products) {
        val q = search.trim()
        if (q.isBlank()) products.take(30)
        else products.filter { it.name.contains(q, ignoreCase = true) }.take(60)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar código $barcode") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Busca el producto y tócalo para asociar este código.")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Buscar producto") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PastelButton(
                    onClick = onCreateNew,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Crear producto nuevo")
                }
                Text("Productos encontrados: ${filtered.size}")
                LazyColumn(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 330.dp)
                ) {
                    items(filtered, key = { it.id }) { product ->
                        PastelOutlinedButton(
                            onClick = { onAssign(product) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(product.name)
                                if (product.category.isNotBlank()) {
                                    Text(product.category, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    priceSummary(product),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) {
                    Text("No se encontró. Usa 'Crear producto nuevo'.")
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun NewProductDialog(
    barcode: String,
    stores: List<StoreInfo>,
    onDismiss: () -> Unit,
    onSave: (String, Map<String, String>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var prices by remember {
        mutableStateOf(stores.associate { it.key to "" })
    }
    val validPrices = prices.values.all { it.isBlank() || it.toDoubleOrNull() != null }
    val canSave = name.trim().isNotBlank() && validPrices

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear producto nuevo") },
        text = {
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 440.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Text("Código: $barcode") }
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nombre del producto") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Text("Captura solo los precios que tengas. El producto se puede guardar aunque tenga un solo precio.")
                }
                items(stores, key = { it.key }) { store ->
                    val value = prices[store.key].orEmpty()
                    val valid = value.isBlank() || value.toDoubleOrNull() != null
                    OutlinedTextField(
                        value = value,
                        onValueChange = { newValue ->
                            prices = prices.toMutableMap().apply {
                                this[store.key] = normalizePriceInput(newValue)
                            }
                        },
                        label = { Text("Precio ${store.label} (opcional)") },
                        singleLine = true,
                        isError = !valid,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            PastelButton(
                onClick = { onSave(name.trim(), prices) },
                enabled = canSave
            ) {
                Text("Guardar producto")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun EditPricesDialog(
    product: Product,
    stores: List<StoreInfo>,
    onDismiss: () -> Unit,
    onSave: (Map<String, String>, String) -> Unit
) {
    var prices by remember(product.id) {
        mutableStateOf(stores.associate { store ->
            store.key to product.prices[store.key].orEmpty()
        })
    }
    var publicPrice by remember(product.id, product.publicPrice) { mutableStateOf(product.publicPrice) }
    var showDianaEditor by remember(product.id) { mutableStateOf(false) }
    val validPublicPrice = publicPrice.isBlank() || publicPrice.toDoubleOrNull() != null
    val validPrices = prices.values.all { it.isBlank() || it.toDoubleOrNull() != null } && validPublicPrice

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar precios") },
        text = {
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 440.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Text(product.name) }
                item { Text("Puedes dejar en blanco las tiendas donde no se venda este artículo.") }
                item {
                    PastelOutlinedButton(
                        onClick = { showDianaEditor = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Modificar precio Diana")
                    }
                }
                if (showDianaEditor) {
                    item {
                        OutlinedTextField(
                            value = publicPrice,
                            onValueChange = { publicPrice = normalizePriceInput(it) },
                            label = { Text("Precio público Diana (editable)") },
                            singleLine = true,
                            isError = !validPublicPrice,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                items(stores, key = { it.key }) { store ->
                    val value = prices[store.key].orEmpty()
                    val valid = value.isBlank() || value.toDoubleOrNull() != null
                    OutlinedTextField(
                        value = value,
                        onValueChange = { newValue ->
                            prices = prices.toMutableMap().apply {
                                this[store.key] = normalizePriceInput(newValue)
                            }
                        },
                        label = { Text("Precio ${store.label}") },
                        singleLine = true,
                        isError = !valid,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (!validPrices) {
                    item { Text("Usa solo números y punto decimal, por ejemplo 85.50.") }
                }
            }
        },
        confirmButton = {
            PastelButton(
                onClick = { onSave(prices, publicPrice) },
                enabled = validPrices
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun TicketStoreDialog(
    stores: List<StoreInfo>,
    onDismiss: () -> Unit,
    onCreateStore: () -> Unit,
    onSelect: (StoreInfo) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Selecciona la tienda del ticket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("¿De qué tienda es el ticket? Los precios detectados se guardarán en esa tienda.")
                PastelButton(onClick = onCreateStore, modifier = Modifier.fillMaxWidth()) {
                    Text("Crear tienda")
                }
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                    items(stores, key = { it.key }) { store ->
                        PastelOutlinedButton(
                            onClick = { onSelect(store) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Text(store.label)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun CreateStoreDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear tienda") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Escribe el nombre de la nueva tienda. Quedará disponible para tickets y precios.")
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre de la tienda") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            PastelButton(onClick = { onCreate(name.trim()) }, enabled = name.trim().length >= 2) {
                Text("Crear y tomar foto")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ReceiptReviewDialog(
    target: StoreInfo?,
    items: List<ReceiptItem>,
    message: String?,
    onDismiss: () -> Unit,
    onAssign: (Int) -> Unit,
    onApply: (List<ReceiptItem>) -> Unit
) {
    var selected by remember(items) {
        mutableStateOf(
            items.indices.filter { index ->
                val item = items[index]
                item.productId != null && item.score >= 0.60
            }.toSet()
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Precios detectados · ${target?.label ?: "Ticket"}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                message?.let { Text(it) }
                Text("Revisa todos los renglones antes de guardar. Ningún precio se modifica hasta que pulses 'Aplicar precios'. Si un nombre no coincide, toca 'Asignar producto'.")
                if (items.isNotEmpty()) {
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                        items(items.indices.toList()) { index ->
                            val item = items[index]
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Column(
                                    Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Checkbox(
                                            checked = index in selected,
                                            enabled = item.productId != null,
                                            onCheckedChange = { checked ->
                                                selected = if (checked) selected + index else selected - index
                                            }
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                item.productName ?: "Sin producto asociado",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text("Precio detectado: ${formatPrice(item.price)}")
                                            Text("Ticket: ${item.rawLine}", style = MaterialTheme.typography.bodySmall)
                                            if (item.productId != null && item.score < 0.60) {
                                                Text("Coincidencia dudosa: confirma o cambia el producto.", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                    PastelOutlinedButton(
                                        onClick = { onAssign(index) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (item.productId == null) "Asignar producto" else "Cambiar producto")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            PastelButton(
                onClick = { onApply(items.filterIndexed { index, _ -> index in selected }) },
                enabled = selected.isNotEmpty()
            ) {
                Text("Aplicar precios")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ReceiptProductPickerDialog(
    receiptItem: ReceiptItem,
    products: List<Product>,
    onDismiss: () -> Unit,
    onAssign: (Product) -> Unit
) {
    var search by remember(receiptItem.rawLine) { mutableStateOf("") }
    val filtered = remember(search, products) {
        val q = search.trim()
        if (q.isBlank()) products.take(35)
        else products.filter { it.name.contains(q, ignoreCase = true) }.take(70)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Asignar producto del ticket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ticket: ${receiptItem.rawLine}")
                Text("Precio: ${formatPrice(receiptItem.price)}")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Buscar producto") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 330.dp)) {
                    items(filtered, key = { it.id }) { product ->
                        PastelOutlinedButton(
                            onClick = { onAssign(product) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(product.name)
                                if (product.category.isNotBlank()) {
                                    Text(product.category, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

private fun csvEscape(value: String): String {
    val escaped = value.replace("\"", "\"\"")
    return if (escaped.contains(',') || escaped.contains('\n') || escaped.contains('\r') || escaped.contains('"')) {
        "\"$escaped\""
    } else escaped
}

private fun writeArticleBarcodeFile(
    context: Context,
    products: List<Product>,
    store: LocalStore
): File {
    val directory = File(context.filesDir, "exports").apply { mkdirs() }
    val file = File(directory, "articulos_codigos.csv")
    val assigned = store.assignedCodes()
    val codesByProduct = linkedMapOf<String, LinkedHashSet<String>>()

    products.forEach { product ->
        if (product.code.isNotBlank()) {
            codesByProduct.getOrPut(product.id) { linkedSetOf() }.add(product.code.trim())
        }
    }
    assigned.forEach { (barcode, productId) ->
        if (barcode.isNotBlank()) {
            codesByProduct.getOrPut(productId) { linkedSetOf() }.add(barcode.trim())
        }
    }

    OutputStreamWriter(file.outputStream(), Charsets.UTF_8).use { out ->
        out.append("articulo,codigo_barras,categoria\n")
        products.forEach { product ->
            val codes = codesByProduct[product.id].orEmpty()
            if (codes.isEmpty()) {
                out.append(csvEscape(product.name)).append(',')
                    .append(',')
                    .append(csvEscape(product.category)).append('\n')
            } else {
                codes.forEach { barcode ->
                    out.append(csvEscape(product.name)).append(',')
                        .append(csvEscape(barcode)).append(',')
                        .append(csvEscape(product.category)).append('\n')
                }
            }
        }
    }
    return file
}

private fun shareArticleBarcodeFile(
    context: Context,
    products: List<Product>,
    store: LocalStore
) {
    val file = writeArticleBarcodeFile(context, products, store)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Guardar o compartir artículos y códigos"))
}

private fun writeUpdatedCostsFile(
    context: Context,
    products: List<Product>,
    store: LocalStore
): File {
    val directory = File(context.filesDir, "exports").apply { mkdirs() }
    val file = File(directory, "costos_actualizados.csv")
    val assigned = store.assignedCodes()
    val codesByProduct = linkedMapOf<String, LinkedHashSet<String>>()
    products.forEach { product ->
        if (product.code.isNotBlank()) {
            codesByProduct.getOrPut(product.id) { linkedSetOf() }.add(product.code.trim())
        }
    }
    assigned.forEach { (barcode, productId) ->
        if (barcode.isNotBlank()) {
            codesByProduct.getOrPut(productId) { linkedSetOf() }.add(barcode.trim())
        }
    }

    OutputStreamWriter(file.outputStream(), Charsets.UTF_8).use { out ->
        val headers = mutableListOf("articulo", "codigo_barras", "categoria")
        val exportStores = store.allStores()
        headers += exportStores.map { it.key }
        headers += listOf("precio_publico_diana", "comentarios_archivo", "comentarios_actualizados", "historial_app")
        out.append(headers.joinToString(",") { csvEscape(it) }).append('\n')
        products.forEach { product ->
            val codes = codesByProduct[product.id].orEmpty().joinToString(" | ")
            val values = mutableListOf(product.name, codes, product.category)
            exportStores.forEach { storeInfo ->
                values += store.price(product, storeInfo.key)
            }
            values += store.publicPrice(product)
            values += product.sourceComments
            values += store.editableComments(product)
            values += store.history(product.id).joinToString(" | ")
            out.append(values.joinToString(",") { csvEscape(it) }).append('\n')
        }
    }
    return file
}

private fun shareUpdatedCostsFile(
    context: Context,
    products: List<Product>,
    store: LocalStore
) {
    val file = writeUpdatedCostsFile(context, products, store)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Guardar o compartir costos actualizados"))
}

private fun createTicketPhotoUri(context: Context): Uri {
    val directory = File(context.cacheDir, "tickets").apply { mkdirs() }
    val file = File.createTempFile("ticket_", ".jpg", directory)
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun buildReceiptItems(
    text: String,
    products: List<Product>,
    store: LocalStore
): List<ReceiptItem> {
    val priceRegex = Regex("(?:\\$\\s*)?(\\d{1,5}(?:[.,]\\d{1,2})?)\\s*$")
    val excluded = listOf(
        "total", "subtotal", "cambio", "efectivo", "tarjeta", "iva", "pago", "ahorro",
        "importe", "saldo", "recibido", "descuento"
    )
    val parsed = mutableListOf<Pair<String, Pair<String, String>>>()
    var previousDescription: String? = null

    text.lineSequence().forEach { raw ->
        val line = raw.trim()
        if (line.isBlank()) return@forEach
        val lower = line.lowercase(Locale.ROOT)
        if (excluded.any { lower.contains(it) }) {
            previousDescription = null
            return@forEach
        }

        val priceMatch = priceRegex.find(line)
        if (priceMatch != null) {
            val price = priceMatch.groupValues[1].replace(',', '.')
            val number = price.toDoubleOrNull()
            if (number == null || number <= 0.0 || number > 100000.0) return@forEach

            var description = line.substring(0, priceMatch.range.first).trim(' ', '-', ':', '.', '*')
            if (description.length < 3) {
                description = previousDescription.orEmpty()
            }
            if (description.length >= 3) {
                parsed += line to (description to price)
            }
            previousDescription = null
        } else if (line.length >= 3 && line.any(Char::isLetter)) {
            previousDescription = line
        }
    }

    val dedup = linkedMapOf<String, ReceiptItem>()
    parsed.forEach { (rawLine, pair) ->
        val (description, price) = pair
        val aliasId = store.receiptAlias(description)
        val aliasProduct = aliasId?.let { id -> products.firstOrNull { it.id == id } }
        val candidate = if (aliasProduct != null) {
            aliasProduct to 1.0
        } else {
            findBestProduct(description, products)
        }

        val item = ReceiptItem(
            rawLine = rawLine,
            description = description,
            price = price,
            productId = candidate?.first?.id,
            productName = candidate?.first?.name,
            score = candidate?.second ?: 0.0
        )
        val key = "${receiptAliasKey(description)}|$price"
        dedup[key] = item
    }

    return dedup.values.toList()
}

private fun findBestProduct(description: String, products: List<Product>): Pair<Product, Double>? {
    val descTokens = matchTokens(description)
    if (descTokens.isEmpty()) return null

    var best: Product? = null
    var bestScore = 0.0
    var bestMatched = 0
    var bestStrong = false

    for (product in products) {
        val productTokens = matchTokens(product.name)
        if (productTokens.isEmpty()) continue
        var matched = 0
        var strong = false
        descTokens.forEach { d ->
            val hit = productTokens.firstOrNull { p ->
                p == d ||
                    (p.length >= 4 && d.length >= 4 && (p.startsWith(d) || d.startsWith(p))) ||
                    (p.length >= 6 && d.length >= 6 && (p.contains(d) || d.contains(p)))
            }
            if (hit != null) {
                matched++
                if (d.length >= 5 || hit.length >= 5) strong = true
            }
        }
        val denominator = minOf(descTokens.size, productTokens.size).coerceAtLeast(1)
        var score = matched.toDouble() / denominator.toDouble()
        val descNorm = receiptAliasKey(description)
        val productNorm = receiptAliasKey(product.name)
        if (descNorm.length >= 5 && productNorm.contains(descNorm)) score += 0.25
        if (productNorm.length >= 5 && descNorm.contains(productNorm)) score += 0.25
        score = score.coerceAtMost(1.0)

        if (score > bestScore) {
            bestScore = score
            bestMatched = matched
            bestStrong = strong
            best = product
        }
    }

    val enough = best != null && (
        bestScore >= 0.60 ||
            (bestScore >= 0.45 && bestMatched >= 2) ||
            (bestScore >= 0.38 && bestMatched >= 1 && bestStrong)
        )
    return if (enough) best!! to bestScore else null
}

private fun receiptAliasKey(value: String): String {
    val normalized = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
    return normalized.take(120)
}

private fun matchTokens(value: String): List<String> {
    val normalized = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
    val ignored = setOf(
        "cj", "caja", "paq", "paquete", "pzs", "pza", "pzas", "gr", "kg", "ml", "lt", "lts",
        "con", "sin", "para", "del", "las", "los", "una", "uno", "por"
    )
    return normalized.split(Regex("\\s+"))
        .map { it.trim() }
        .filter { it.length >= 3 && it !in ignored && !it.all(Char::isDigit) }
}

private fun normalizePriceInput(value: String): String = value.replace(',', '.').filter {
    it.isDigit() || it == '.'
}

private fun formatPrice(value: String): String {
    val number = value.toDoubleOrNull() ?: return "Sin precio"
    return money(number)
}

private fun money(value: Double): String = String.format(Locale.US, "\$%.2f", value)

private fun playScanBeep(context: Context) {
    try {
        val player = MediaPlayer.create(context, R.raw.scan_beep)
        if (player != null) {
            player.setVolume(1.0f, 1.0f)
            player.setOnCompletionListener { it.release() }
            player.start()
            return
        }
    } catch (_: Exception) { }
    try {
        val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 220)
        Handler(Looper.getMainLooper()).postDelayed({
            try { tone.release() } catch (_: Exception) { }
        }, 300)
    } catch (_: Exception) { }
}


@Composable
fun BarcodeScanner(onScan: (String) -> Unit) {
    val context = LocalContext.current
    var lastEmitted by remember { mutableStateOf("") }
    var lastEmittedAt by remember { mutableStateOf(0L) }

    AndroidView(
        factory = { ctx ->
            val view = PreviewView(ctx).apply {
                // Usa TextureView para respetar el orden de capas de Compose.
                // Evita que la vista de cámara se dibuje encima de botones y diálogos.
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            val provider = ProcessCameraProvider.getInstance(ctx)
            provider.addListener({
                val cameraProvider = provider.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = view.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val scanner = BarcodeScanning.getClient()
                val executor = Executors.newSingleThreadExecutor()

                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media != null) {
                        scanner.process(
                            InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        )
                            .addOnSuccessListener { codes ->
                                codes.firstOrNull()?.rawValue?.let { raw ->
                                    val now = System.currentTimeMillis()
                                    if (raw != lastEmitted || now - lastEmittedAt > 1500L) {
                                        lastEmitted = raw
                                        lastEmittedAt = now
                                        onScan(raw)
                                    }
                                }
                            }
                            .addOnCompleteListener { proxy.close() }
                    } else {
                        proxy.close()
                    }
                }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    context as ComponentActivity,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            }, ContextCompat.getMainExecutor(ctx))
            view
        },
        modifier = Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(14.dp))
    )
}
